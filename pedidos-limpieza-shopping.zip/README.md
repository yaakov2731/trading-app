# Pedidos Limpieza - Shopping Tigre

Sistema de órdenes de compra para artículos de **Limpieza, Papelería y Descartables**.

## Archivos incluidos

| Archivo | Descripción |
|---|---|
| `Plantilla_Pedido_Limpieza_Shopping_Tigre.xlsx` | Plantilla maestra con catálogo completo (~80 artículos) |
| `OC_CleanMax_Marzo2026.xlsx` | Ejemplo de orden de compra generada para CleanMax |
| `catalogo_demo_proveedor.pdf` | PDF de catálogo de ejemplo para probar el importador |
| `generate_template.js` | Genera la plantilla Excel desde cero |
| `import_catalogo_pdf.js` | Importa un catálogo PDF y genera una OC en Excel |
| `extract_pdf.mjs` | Extrae texto de un PDF (módulo ESM auxiliar) |
| `crear_catalogo_demo.js` | Crea el PDF de catálogo demo |

## Requisitos

- Node.js 18+

## Instalación

```bash
npm install
```

## Uso

### Generar plantilla de pedido

```bash
node generate_template.js
# → genera Plantilla_Pedido_Limpieza_Shopping_Tigre.xlsx
```

### Importar catálogo PDF de un proveedor

```bash
node import_catalogo_pdf.js catalogo_proveedor.pdf --proveedor "Nombre Proveedor"
# → genera OC_NombreProveedor_MMAAAA.xlsx
```

Con nombre de salida personalizado:

```bash
node import_catalogo_pdf.js lista_precios.pdf --proveedor "CleanMax" --out pedido_abril.xlsx
```

### Crear catálogo demo (para pruebas)

```bash
node crear_catalogo_demo.js
# → genera catalogo_demo_proveedor.pdf
```

## Estructura de la Plantilla Excel

La plantilla incluye las siguientes categorías de productos:

- **Limpiadores y Desinfectantes** (LD-001 a LD-012)
- **Papel Higiénico y Toallas** (PH-001 a PH-004)
- **Descartables** (DC-001 a DC-008)
- **Útiles de Limpieza** (UL-001 a UL-010)
- **Papelería y Oficina** (PA-001 a PA-008)
- **Bolsas de Residuos** (BR-001 a BR-006)

Cada producto tiene: Código, Descripción, Presentación, Unidad, Precio Ref., Stock Actual, Cantidad a Pedir, Subtotal.

## Próximos pasos (app automatizada)

- [ ] Conectar con base de datos (Supabase / SQLite) para historial de pedidos
- [ ] Dashboard web para gestión de stock
- [ ] Alertas de stock mínimo por artículo
- [ ] Multi-proveedor con comparación de precios
- [ ] Envío automático de OC por email al proveedor
